
package tourism.management.system;



import java.sql.*;  


    
  public class Conn{

    
    Connection c;
    Statement s;
    public Conn(){  
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            c = DriverManager.getConnection(
                    "jdbc:sqlserver://localhost:1433;databaseName=TMS;selectMethod=cursor", "sa", "123456");
            
           // System.out.println(Conn.getMetaData().getDatabaseProductName() + "DATABASE NAME IS:");
            
            s =c.createStatement();  
            
           
        }catch(Exception e){ 
            System.out.println(e);
        }  
    }
    //public static void main(String[] args) {
       //Conn cnObj = new Conn();
        //cnObj.connectDB();
    
}  
    
    
     
        
    
    

