
package tourism.management.system;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class bKash extends JFrame{
    bKash(){
        JEditorPane j = new JEditorPane();
        j.setEditable(false);   
        
        try{
            j.setPage("http://bKash.com");
        }catch(Exception e)
        {
            j.setContentType("text/html");
            j.setText("<html>Could not load, Error 404<html>");
        }
        
        add(j);

        setBounds(670,240,800,600);
    }
    public static void main(String[] args){
        new bKash().setVisible(true);
    }
    
}