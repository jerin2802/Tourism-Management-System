
package tourism.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SignUp extends JFrame implements ActionListener{
    JButton b1, b2;
    JTextField t1, t2, t3, t4;
    Choice c1;
    SignUp(){
        
        getContentPane().setBackground(Color.WHITE);
        setBounds(600, 250, 900, 400);
        setLayout(null); //BorderLayout, FlowLayout, GridLayout, Grid//
        
        JPanel p1 = new JPanel();
        p1.setBackground(new Color(133,193,233));
        p1.setBounds(0, 0, 500, 400);
        p1.setLayout(null);
        add(p1);
        
        JLabel l1 = new JLabel("Username");
        l1.setFont(new Font("Tahoma", Font.BOLD, 14));
        l1.setBounds(50, 20, 140, 25);
        p1.add(l1);
        
        
        t1 = new JTextField();
        t1.setBounds(200, 20, 180, 25);
        t1.setBorder(BorderFactory.createEmptyBorder());
        add(t1);
        
        
        JLabel l2 = new JLabel("Name");
        l2.setFont(new Font("Tahoma", Font.BOLD, 14));
        l2.setBounds(50, 70, 140, 25);
        p1.add(l2);
        
        
        t2 = new JTextField();
        t2.setBounds(200, 70, 180, 25);
        t2.setBorder(BorderFactory.createEmptyBorder());
        add(t2);
        
        JLabel l3 = new JLabel("Password");
        l3.setFont(new Font("Tahoma", Font.BOLD, 14));
        l3.setBounds(50, 120, 140, 25);
        p1.add(l3);
        
        
        t3 = new JTextField();
        t3.setBounds(200, 120, 180, 25);
        t3.setBorder(BorderFactory.createEmptyBorder());
        add(t3);
        
        JLabel l4 = new JLabel("Your Security Query");
        l4.setFont(new Font("Tahoma", Font.BOLD, 14));
        l4.setBounds(50, 170, 140, 25);
        p1.add(l4);
        
        c1 = new Choice();
        c1.add("What was your childhood nickname?");
        c1.add("What is the last name of your eldest cousin");
        c1.add("In what city did your mother and father meet?");
        c1.add("Your Lucky Number?");
        c1.add("Superman or Ironman?");        
        c1.setBounds(200, 170, 220,25);
        p1.add(c1);
        
        JLabel l5 = new JLabel("Answer");
        l5.setFont(new Font("Tahoma", Font.BOLD, 14));
        l5.setBounds(50, 220, 140, 25);
        p1.add(l5);
        
        
        t4 = new JTextField();
        t4.setBounds(200, 220, 180, 25);
        t4.setBorder(BorderFactory.createEmptyBorder());
        add(t4);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("tourism/management/system/icons/signup.png"));
        Image i2 = i1.getImage().getScaledInstance(250,250, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l6 = new JLabel(i3);
        l6.setBounds(580, 50, 250, 250);
        add(l6);
        
        
        
        
        b1 = new JButton("Create");
        b1.setFont(new Font("Tahoma", Font.BOLD, 14));
        b1.setBounds(100, 280, 100, 30);
        b1.setForeground(Color.MAGENTA);
        b1.setBackground(Color.WHITE);
        b1.addActionListener(this);
        b1.setBorder(BorderFactory.createEmptyBorder());
        p1.add(b1); 
        
        b2 = new JButton("Back");
        b2.setBounds(250, 280, 100, 30);
        b2.setForeground(Color.MAGENTA);
        b2.setBackground(Color.WHITE);
        b2.addActionListener(this);
        b2.setBorder(BorderFactory.createEmptyBorder());
        p1.add(b2); 
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()== b1){
            
            String username = t1.getText();
            String name = t2.getText();
            String password = t3.getText();
            String security = c1.getSelectedItem();
            String answer = t4.getText();
            
            String query = "insert into account values('"+username+"', '"+name+"','"+password+"','"+security+"','"+answer+"')"; 
            try{
                Conn c = new Conn();
                c.s.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Account Created Successfully");
                
                this.setVisible(false);
                new Login().setVisible(true);
                
                
                
                        
                
                
            }catch(Exception e){
                
            }
                   
            
        }else if(ae.getSource() == b2){
            new Login().setVisible(true);
            this.setVisible(false);
            
        }
    }
    
    
    public static void main(String[] args){
        new SignUp().setVisible(true);
        
    }
    
}
